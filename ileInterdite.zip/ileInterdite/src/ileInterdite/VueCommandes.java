package ileInterdite;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class VueCommandes extends JPanel {
	
	public JButton boutonFDT;
	public JButton boutonUP;
	public JButton boutonDOWN;
	public JButton boutonLEFT;
	public JButton boutonRIGHT;
	public JButton boutonASSECHER;
	public JButton boutonGETARTEFACT;
	public JButton boutonFINPARTIE ;
	
	public VueCommandes( ModeleIle model) {
		Controleur controleur = new Controleur( model, this);
		
		this.boutonFDT = new JButton( "Fin de tour");
		this.add( boutonFDT);
		this.boutonFDT.addActionListener( controleur);
		
		this.boutonUP = new JButton( "^");
		this.add( boutonUP);
		this.boutonUP.addActionListener( controleur);
		
		this.boutonDOWN = new JButton( "v");
		this.add( boutonDOWN);
		this.boutonDOWN.addActionListener( controleur);
		
		this.boutonLEFT = new JButton( "<");
		this.add( boutonLEFT);
		this.boutonLEFT.addActionListener( controleur);
		
		this.boutonRIGHT = new JButton( ">");
		this.add( boutonRIGHT);
		this.boutonRIGHT.addActionListener( controleur);
		
		this.boutonASSECHER = new JButton( "Ass�cher");
		this.add( boutonASSECHER);
		this.boutonASSECHER.addActionListener( controleur);
		
		this.boutonGETARTEFACT = new JButton( "Get artefact");
		this.add( boutonGETARTEFACT);
		this.boutonGETARTEFACT.addActionListener( controleur);
		
		this.boutonFINPARTIE = new JButton( "FIN DE PARTIE");
		this.add(boutonFINPARTIE );
		this.boutonFINPARTIE.addActionListener( controleur);
	}
	
	public void assecher() {
		
		JLabel message = new JLabel( "Cliquez sur la zone que vous voulez ass�cher"); // Ce message n'apparait qu'une fois la fen�tre du jeu agrandie
																					  // Mais seulement si on agrandit la fen�tre et non si elle l'est d�j�
		message.setFont( new Font( "Verdana", 1, 10));
		this.add(message);
		message.setVisible(true);

		   int delay = 10000/2; //milliseconds
		   ActionListener taskPerformer = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				message.setVisible(false);
			}
			
		   };
		   
		   new Timer(delay, taskPerformer).start();
	}

}
