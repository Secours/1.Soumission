package ileInterdite;

import java.util.*;
import java.awt.Color;
import java.io.IOException;

abstract class Observable {
    /**
     * On a une liste [observers] d'observateurs, initialement vide, à laquelle
     * viennent s'inscrire les observateurs via la méthode [addObserver].
     */
    private ArrayList<Observer> observers;
    public Observable() {
	this.observers = new ArrayList<Observer>();
    }
    public void addObserver(Observer o) {
	observers.add(o);
    }

    /**
     * Lorsque l'état de l'objet observé change, il est convenu d'appeler la
     * méthode [notifyObservers] pour prévenir l'ensemble des observateurs
     * enregistrés.
     * On le fait ici concrètement en appelant la méthode [update] de chaque
     * observateur.
     */
    public void notifyObservers() {
	for(Observer o : observers) {
	    o.update();
	}
    }
}

public class ModeleIle extends Observable {
	
	public int largeur, hauteur;
	public Zone[][] zones;
	public int nbJoueurs;
	public ArrayList<Joueur> joueurs;
	public Joueur joueurActuel;
	Color[] c = {Color.CYAN, Color.MAGENTA, Color.ORANGE, Color.YELLOW, Color.PINK, Color.GRAY, Color.WHITE};
	
	public ModeleIle( int hauteur, int largeur, int nbJ) throws IOException {
		this.largeur = largeur; this.hauteur = hauteur;
		this.zones = new Zone[hauteur][largeur];
		for( int i=0; i < largeur; i++) {
		    for( int j=0; j < hauteur; j++) {
		    	this.zones[i][j] = new Zone( this,i,j);
		    }
		}
		this.nbJoueurs = nbJ;
		this.joueurs = new ArrayList<Joueur>();
		for( int i = 0; i < this.nbJoueurs; i++) {
			Joueur joueur = new Joueur( c[i]);
			joueur.nom = "joueur"+(i+1);
			this.joueurs.add(joueur);
		}
		this.joueurActuel = this.joueurs.get(0);
	}
	
	public String toString() {
        String s;
        for( int i=0; i<this.zones.length; i++) {
            System.out.println();
            for( int j=0; j<this.zones[i].length; j++) {
                if( this.zones[i][j].states[0] == 0) { s = "| 0 |";}
                else if( this.zones[i][j].states[0] == 1) {s = "| 1 |";}
                else {s = "| 2 |";}
                if( this.zones[i][j].states[2] == 1) { s = "| 3 |";}
                System.out.print(s);
            }
        }
        return "";
    }
	
	public int getIndJ( Joueur j) {
		return this.joueurs.indexOf(j);
	}
	
	public void innonder() {
		Random x = new Random(); Random y = new Random();
		for( int i = 0; i < 3; i++) {
			int l = x.nextInt(this.hauteur); int h = y.nextInt(this.largeur);
			if( this.zones[l][h].states[0] < 2) this.zones[l][h].states[0]++;
		}
		notifyObservers();
	}
	
	public void up() {
		if( this.joueurActuel.x > 0) {
			this.joueurActuel.x--;
			this.zones[this.joueurActuel.x][this.joueurActuel.y].states[2] = 1;
		}
		else if( this.joueurActuel.x == 0) {
			this.joueurActuel.x = 0;
		}
		notifyObservers();
	}
	
	public void down() {
		if( this.joueurActuel.x < this.hauteur-1) {
			this.joueurActuel.x++;
			this.zones[this.joueurActuel.x][this.joueurActuel.y].states[2] = 1;
		}
		else if( this.joueurActuel.x == this.hauteur-1) {
			this.joueurActuel.x = this.hauteur-1;
		}
		notifyObservers();
	}
	
	public void right() {
		if( this.joueurActuel.y < this.largeur-1) {
			this.joueurActuel.y++;
			this.zones[this.joueurActuel.x][this.joueurActuel.y].states[2] = 1;
		}
		else if( this.joueurActuel.y == this.largeur-1) {
			this.joueurActuel.y = this.largeur-1;
		}
		notifyObservers();
	}
	
	public void left() {
		if( this.joueurActuel.y > 0) {
			this.joueurActuel.y--;
			this.zones[this.joueurActuel.x][this.joueurActuel.y].states[2] = 1;
		}
		else if( this.joueurActuel.y == 0) {
			this.joueurActuel.y = 0;
		}
		notifyObservers();
	}
	
	public void assecher() {
		if( this.zones[this.joueurActuel.x][this.joueurActuel.y].estInondee()) this.zones[this.joueurActuel.x][this.joueurActuel.y].states[0] = 0;
        notifyObservers();
	}
	
	public void assecher( int x, int y) {
		if( (x == this.joueurActuel.x && y == this.joueurActuel.y)
			|| (x == this.joueurActuel.x && y == this.joueurActuel.y-1)
			|| (x == this.joueurActuel.x && y == this.joueurActuel.y+1) 
			|| (x == this.joueurActuel.x+1 && y == this.joueurActuel.y)
			|| (x == this.joueurActuel.x+1 && y == this.joueurActuel.y-1)
			|| (x == this.joueurActuel.x+1 && y == this.joueurActuel.y+1)
			|| (x == this.joueurActuel.x-1 && y == this.joueurActuel.y)
			|| (x == this.joueurActuel.x-1 && y == this.joueurActuel.y-1)
			|| (x == this.joueurActuel.x-1 && y == this.joueurActuel.y+1) )  {
				if( this.zones[x][y].estInondee()) this.zones[x][y].states[0] = 0;
		}
        notifyObservers();
	}
	
	public enum Cles {CleEAU, CleFEU, CleTERRE, CleAIR, None};

	public Cles getRandomCle() {
		 Cles[] cles = Cles.values();
		 int SIZE = cles.length;
		 Random RANDOM = new Random();
		 return cles[RANDOM.nextInt(SIZE)];
	}
	
	public void addCle() {
		Cles cle = this.getRandomCle();
		if ( cle == Cles.CleAIR) this.joueurActuel.cles[0] = true;
		else if ( cle == Cles.CleEAU) this.joueurActuel.cles[1] = true;
		else if ( cle == Cles.CleFEU) this.joueurActuel.cles[2] = true;
		else if (cle == Cles.CleTERRE) this.joueurActuel.cles[3] = true;
		else if ( cle==Cles.None) {/*on fait rien*/}
	}
	
	public boolean artefactPresent( int x, int y) {
		return ( this.zones[x][y].estSpeciale());
	}
	
	
	public void getArtefact()  {
		if ( this.zones[this.joueurActuel.x][this.joueurActuel.y].estSpeciale()) {
			if( this.zones[this.joueurActuel.x][this.joueurActuel.y].estAir() && this.joueurActuel.cles[0]==true) {
				this.joueurActuel.artefacts[0] = true;
			}
			else if( this.zones[this.joueurActuel.x][this.joueurActuel.y].estEau() && this.joueurActuel.cles[1]==true) {
				this.joueurActuel.artefacts[1] = true;
			}
			else if( this.zones[this.joueurActuel.x][this.joueurActuel.y].estFeu()  && this.joueurActuel.cles[2]==true) {
				this.joueurActuel.artefacts[2] = true;
			}
			else if( this.zones[this.joueurActuel.x][this.joueurActuel.y].estTerre()  && this.joueurActuel.cles[3]==true) {
				this.joueurActuel.artefacts[3] = true;
			}
		}
		System.out.println(this.joueurActuel.artefactsToString());
	}
	
	/**
	 * @return true si le joueur a tous les arctefats
	 */
	public boolean tousARTfReunis() {
		boolean[] arts = {false, false, false, false};

		for( Joueur j : this.joueurs)
			for( int i = 0; i < arts.length; i++)
				arts[i] = arts[i] || j.artefacts[i];

		boolean all = true;
		for( boolean b: arts)
			all = all && b;

		return all;
	}
		
	/*
	 * return true si tous les joueur sont réunis a l'helicoptere
	 */
	public boolean tousAHeliport() {
		for ( int i = 0; i < this.largeur; i++) {
			for ( int j = 0; j < this.hauteur; j++) {
				if( this.zones[i][j].heliportPresent()) {
					Zone zone = this.zones[i][j].getZone();
					for ( Joueur joueur : this.joueurs) {
						if( zone.x == joueur.x && zone.y == joueur.y) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	/*
	 * return true si tous les joueur sont réunis a l'helicoptere et si tous les joueur sont réunis a l'helicoptere
	 */
	public boolean partieGagne() {
		return ( !this.tousAHeliport() && this.tousARTfReunis());
	}

	@SuppressWarnings({ "unused", "resource" })
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner( System.in);
		System.out.println( "Combien de joueurs ?");
		int nbJ = sc.nextInt();
		System.out.println( "C'est parti !");
		ModeleIle model = new ModeleIle( 10, 10, nbJ);
		Vue vue = new Vue( model);
//		model.toString();
//		System.out.println();
//		model.innonder();
//		model.toString();
//		System.out.println();
//		model.right();
//		model.toString();
//		System.out.println();
//		model.down();
//		model.toString();

	}

}
