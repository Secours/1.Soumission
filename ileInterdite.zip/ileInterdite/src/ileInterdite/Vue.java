package ileInterdite;

import java.awt.FlowLayout;
import java.io.IOException;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class Vue extends JFrame {
	
	private VueGrille grille;
	private VueCommandes commandes;
	private VueJoueurs bilan;
	
    public Vue( ModeleIle model) throws IOException {
    	super( "Jeu de la vie de l'Ile Interdite");
    	this.setLayout( new FlowLayout());
    	this.grille = new VueGrille( model);
    	this.add (this.grille);
    	this.commandes = new VueCommandes( model);
    	this.add( this.commandes);
    	this.bilan = new VueJoueurs( model);
    	this.add( this.bilan);
    	
    	
    	this.pack();
    	this.setVisible(true);
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
