package ileInterdite;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controleur implements ActionListener {
	
	private ModeleIle model;
	private VueCommandes commandes;
	
	public Controleur( ModeleIle model, VueCommandes commandes) {
		this.model = model;
		this.commandes = commandes;
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == this.commandes.boutonFDT && this.model.joueurActuel.nbAction <= this.model.joueurActuel.nbActionMAX) {
			this.model.innonder();
			this.model.joueurActuel.nbAction = 0;
			if( this.model.getIndJ(this.model.joueurActuel) < this.model.nbJoueurs-1) {
				this.model.joueurActuel = this.model.joueurs.get(this.model.getIndJ(this.model.joueurActuel)+1);
			} else {
				this.model.joueurActuel = this.model.joueurs.get(0);
			}
		}
		if(e.getSource() == this.commandes.boutonUP && this.model.joueurActuel.nbAction < this.model.joueurActuel.nbActionMAX) {
			this.model.up();
			this.model.joueurActuel.nbAction++;
		}
		if(e.getSource() == this.commandes.boutonDOWN && this.model.joueurActuel.nbAction < this.model.joueurActuel.nbActionMAX) {
			this.model.down();
			this.model.joueurActuel.nbAction++;
		}
		if(e.getSource() == this.commandes.boutonRIGHT && this.model.joueurActuel.nbAction < this.model.joueurActuel.nbActionMAX) {
			this.model.right();
			this.model.joueurActuel.nbAction++;
		}
		if(e.getSource() == this.commandes.boutonLEFT && this.model.joueurActuel.nbAction < this.model.joueurActuel.nbActionMAX) {
			this.model.left();
			this.model.joueurActuel.nbAction++;
		}
		if(e.getSource() == this.commandes.boutonASSECHER && this.model.joueurActuel.nbAction < this.model.joueurActuel.nbActionMAX) {
			this.commandes.assecher();
			this.model.joueurActuel.nbAction++;
		}
		if(e.getSource() == this.commandes.boutonGETARTEFACT && this.model.joueurActuel.nbAction < this.model.joueurActuel.nbActionMAX) {
			this.model.getArtefact();
			this.model.joueurActuel.nbAction++;
		}
		if (e.getSource() == this.commandes.boutonFINPARTIE && this.model.partieGagne()) {
			for (int i=0;i<this.model.largeur;i++) {
				for (int j=0;j<this.model.hauteur;j++) {
						this.model.zones[i][j].setBackground(Color.BLACK);	
				}
			}
		}else {}
    }

}
