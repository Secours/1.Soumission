package ileInterdite;

import java.awt.GridLayout;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

@SuppressWarnings("serial")
public class VueJoueurs extends JPanel implements Observer {
	
	@SuppressWarnings("unused")
	private ModeleIle model;
	
	public VueJoueurs( ModeleIle model) {
		model.addObserver(this);
		
		//Les titres des colonnes
	    String  title[] = {"Joueurs", "Cl�s", "Artefact"};
		
	    //Les donn�es du tableau
	    Object[][] data = new Object[model.nbJoueurs][title.length];
	    
	    int i = -1;	    
	    for( Joueur joueur : model.joueurs) {
	    	i+=1;
	    		data[i][0] = joueur.nom;
	    		data[i][1] = joueur.clesToString();
	    		data[i][2] = joueur.artefactsToString();
	    	}
	    
	    JTable tableau = new JTable(data, title);
	    JScrollPane scrollPane = new JScrollPane(tableau);
	    
	    setLayout(new GridLayout(1, 0)); 
	    add(scrollPane);
	    }
	    
	    

	@Override
	public void update() {
		repaint();
	}
	
	

}
