package ileInterdite;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
//import java.util.Observer;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

interface Observer {
    /**
     * Un observateur doit posséder une méthode [update] déclenchant la mise à
     * jour.
     */
    public void update();
    /**
     * La version officielle de Java possède des paramètres précisant le
     * changement qui a eu lieu.
     */
}

@SuppressWarnings("serial")
public class VueGrille extends JPanel implements Observer, MouseListener {
	
	private ModeleIle model;
	
    public VueGrille( ModeleIle model) throws IOException {
    	this.model = model;
    	model.addObserver( this);
    	
    	setLayout( new GridLayout( model.hauteur, model.largeur, 5, 5));
    	
    	for( int i = 0; i < model.hauteur; i++) {
    		for( int j = 0; j < model.largeur; j++) {
    			this.add( model.zones[i][j]);
    			//for( Joueur joueur : model.joueurs) ajouterJoueur( i, j, joueur);
    		}
    	}
    	initSpecialZones();
    	addMouseListener(this);
    }
    
    public void paintComponent() {
    	super.repaint();
    	for( int i = 0; i < this.model.hauteur; i++) {
    		for( int j = 0; j < this.model.largeur; j++) {
    			paint( this.model.zones[i][j]);
    			for( Joueur p : this.model.joueurs) ajouterJoueur( i, j, p);
    		}
    	}
    }
    
    private void paint( Zone z) {
    	if( z.estSeche()) z.setBackground( Color.green);
    	else if( z.estInondee()) z.setBackground( Color.orange);
    	else if( z.estSubmergee()) z.setBackground( Color.red);
    }
    
    private void ajouterJoueur( int i, int j, Joueur p) {
    	if( this.model.zones[i][j].joueurPresent( p)) this.model.zones[i][j].add( p);
    }
    
    public void initSpecialZones() throws IOException {
    	String[] elements = {"AIR","EAU","TERRE","FEU","HELIPORT"};
    	for( String element : elements) {
    		specialZone( element);
    	}
    }
    
    public void specialZone( String element) throws IOException {
    	Random x = new Random(); Random y = new Random();
    	int x1, y1;
    	do {
    		x1 = x.nextInt( this.model.hauteur);
    		y1 = y.nextInt( this.model.largeur);
    	} while( this.model.zones[x1][y1].estSpeciale());
    	
    	if( element == "HELIPORT") {
    		BufferedImage helice = ImageIO.read(new File( "C:\\Users\\maria\\Downloads\\helipadasph.jpg"));
    	    JLabel picLabel = new JLabel(new ImageIcon( helice.getScaledInstance(60, 60, Image.SCALE_FAST)));
    	    this.model.zones[x1][y1].add( picLabel);
    	    this.model.zones[x1][y1].setBackground( Color.BLACK);;
    	    this.model.zones[x1][y1].states[1] = 1;
    	    this.model.zones[x1][y1].states[3] = 4;
//    	    for( Joueur joueur : this.model.joueurs) {
//    	    	this.model.zones[x1][y1].add( joueur);
//    	    }
    	}
    	
    	else {
    		JLabel elt = new JLabel( element.toUpperCase());
    		elt.setFont( new Font( "Verdana",1,33));
    	    this.model.zones[x1][y1].add( elt);
    	    elt.setBorder( new LineBorder( Color.BLACK));
    	    this.model.zones[x1][y1].states[1] = 1;
    	    if( element == "AIR") this.model.zones[x1][y1].states[3] = 4;
    	    else if( element == "EAU") this.model.zones[x1][y1].states[3] = 4;
    	    else if( element == "TERRE") this.model.zones[x1][y1].states[3] = 4;
    	    else if( element == "FEU") this.model.zones[x1][y1].states[3] = 4;
    	}
    }

	public void update() {
		paintComponent();
		
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		int dimX = this.model.largeur*this.model.zones[0][0].dimX+5*(this.model.largeur-1);
		int dimY = this.model.hauteur*this.model.zones[0][0].dimY+5*(this.model.hauteur-1);
		this.model.assecher( e.getY()*this.model.largeur/dimY, e.getX()*this.model.hauteur/(dimX));
	}

	@Override
	public void mouseEntered(MouseEvent e) {}

	@Override
	public void mouseExited(MouseEvent e) {}

	@Override
	public void mousePressed(MouseEvent e) {}

	@Override
	public void mouseReleased(MouseEvent e) {}

}
