package ileInterdite;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Random;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class Joueur extends JPanel {
	
	ModeleIle model;
	String nom;
	int x; int y;
	final int nbActionMAX = 3;
	int nbAction;
	Color c;
	//les artefects du joueur
		/*artefects[0]-> air
		 *artefects[1]->eau
		 *artefects[2]->feu
		 *artefects[3]->terre
		 */
	public boolean[] artefacts;
		
	//les cles du joueur rangé de cette façon cles[0]=true si le joueur a la cleAIR
		/*cles[1] = true si cleEAU,
		 *cles[2] = true si cleFeu,
		 *cles[3] = true si cleTerre,
		 */
	public boolean[] cles;
	
	public Joueur( Color c) {
		this.x = 0;
		this.y = 0;
		this.c = c;
		this.artefacts = new boolean[4];
		this.cles = new boolean[4];
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
	    Graphics2D g2d = (Graphics2D) g;
	    g2d.setColor(this.c);

	    for (int i = 0; i <= 100000; i++) {
	      Dimension size = getSize();
	      int w = size.width ;
	      int h = size.height;

	      Random r = new Random();
	      int x = Math.abs(r.nextInt()) % w;
	      int y = Math.abs(r.nextInt()) % h;
	      g2d.drawLine(x, y, x, y);
	    }
	}
	
	/**
	 * initialise les tableaux de boolean a false
	 */
	public void initiateItems() {
		for ( int i = 0; i < 4; i++) {
			this.artefacts[i] = false;
			this.cles[i] = false;
		}
	}
	
	public String clesToString() {
		String result = "";
		result += ( this.cles[0] ? "AIR" : " - ");
		result += ( this.cles[1] ? "EAU" : " - ");
		result += ( this.cles[2] ? "FEU" : " - ");
		result += ( this.cles[3] ? "TERRE" : " -" );
		return result;
	}
	
	public String artefactsToString() {
		String result = "";
		result += ( this.artefacts[0] ? "AIR" : " -");
		result += ( this.artefacts[1] ? "EAU" : " -");
		result += ( this.artefacts[2] ? "FEU" : " -");
		result += ( this.artefacts[3] ? "TERRE" : " -" );
		return result;
	}

}
