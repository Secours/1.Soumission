package ileInterdite;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class Zone extends JPanel {
	
	private ModeleIle model;
	protected int[] states; // un tableau d'entier qui repr�sente les diff�rents etats de la zone
							// case 0 : 0 (s�che); 1 (innond�e); 2 (submerg�e)
							// case 1 : 0 (ordinaire); 1 (sp�ciale)
							// case 2 : 0 (ne contient pas de joueur); 1 (contient un joueur)
	public int x, y;
	public final int dimX = 70, dimY = 70;
	
	public Zone( ModeleIle model, int x, int y) {
		setPreferredSize( new Dimension(dimX, dimY));
		this.setModel(model);
		this.x = x; this.y = y;
		this.states = new int[4];
		this.states[0] = 0;
		this.states[1] = 0;
		this.states[2] = 0;
		setBackground( Color.green); //zone normale de couleur verte
	}
	
    public boolean estSeche() {
        return ( this.states[0] == 0);
    }
    
    public boolean estInondee() {
    	return ( this.states[0] == 1);
    }
    
    public boolean estSubmergee() {
    	return ( this.states[0] == 2);
    }
    
    public boolean estSpeciale() {
    	return ( this.states[1] == 1);
    }
    
    public boolean joueurPresent() {
    	return ( this.states[2] == 1);
    }
    
    public boolean joueurPresent( Joueur j) {
    	return ( this.x == j.x && this.y == j.y);
    }
    
    public boolean estAir() {
        return ( this.states[3] == 0);
    }
    
    public boolean estEau() {
        return ( this.states[3] == 1);
    }
    
    public boolean estFeu() {
        return ( this.states[3] == 2);
    }
    
    public boolean estTerre() {
        return ( this.states[3] == 3);
    }
    
    public Zone getZone() {
		return this;
    }
    
    public boolean heliportPresent() {
        return ( this.states[3] == 4);
    }

	public ModeleIle getModel() {
		return model;
	}

	public void setModel(ModeleIle model) {
		this.model = model;
	}

}
